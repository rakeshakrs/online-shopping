export class Task {

    id: string;
    parent_id: string;
    task_name: string;
    start_date: string;
    end_date: string;
    priority: string;
  }