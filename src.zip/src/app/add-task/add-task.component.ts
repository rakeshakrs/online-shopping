import { Component } from '@angular/core';
import { Router } from '@angular/router';

import { Task } from '../models/task.model';
import { TaskService } from '../services/task.service';

@Component({
  templateUrl: './add-task.component.html'
})
export class AddTaskComponent {

  task: Task = new Task();

  constructor(private router: Router, private taskService: TaskService) {

  }

  createTask(): void {
    this.taskService.createTask(this.task)
        .subscribe( data => {
          alert("User created successfully.");
        });

  };

}