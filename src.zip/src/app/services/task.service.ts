import {Injectable} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Task } from '../models/task.model';


const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class TaskService {

  constructor(private http:HttpClient) {}

  private taskUrl = '/api';

  public getTasks() {
    return this.http.get(this.taskUrl);
  }

  public deleteTask(task) {
    return this.http.delete(this.taskUrl + "/"+ task.id);
  }

  public createTask(task) {
    return this.http.post(this.taskUrl, task);
  }

}