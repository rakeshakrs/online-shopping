import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { Task } from '../models/task.model';
import { TaskService } from '../services/task.service';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styles: []
})
export class TaskComponent implements OnInit {

  tasks: Task[];

  constructor(private router: Router, private taskService: TaskService) {

  }

  ngOnInit() {
    this.taskService.getTasks()
      .subscribe( data => {
        this.tasks= data;
      });
  };

  deleteTask(task: Task): void {
    this.taskService.deleteTask(task)
      .subscribe( data => {
        this.tasks = this.tasks.filter(u => u !== task);
      })
  };

}