import { Task.Model } from './task.model';

describe('Task.Model', () => {
  it('should create an instance', () => {
    expect(new Task.Model()).toBeTruthy();
  });
});
