export class Task {
    id : number;
    parent_id : number;
    task_name : String;
    start_date : Date;
    end_date : Date;
    priorityFrom : number;
    priorityTo : number;
}
