import { Component, OnInit } from '@angular/core';
import {NgForm} from '@angular/forms';
import {TaskService} from '../shared/task.service';
import {ToastrService} from 'ngx-toastr';
@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.css']
})
export class TaskComponent implements OnInit {

  constructor(private taskService: TaskService,private toastrService: ToastrService) { }

  ngOnInit() {
    this.resetForm(null);
  }
  resetForm(form : NgForm){
    
    if(form!=null)
    form.reset();
    this.taskService.selectedTask={
      id:null,
      parent_id:null,
      task_name:'',
      start_date:null,
      end_date:null,
      priorityFrom:null,
      priorityTo:null
    }
  }
  onSubmit(form : NgForm){
    this.taskService.postTask(form.value)
    .subscribe(data =>{
      this.resetForm(form);
      this.toastrService.success('New Record added','Task Manager');
    })
  }
}
